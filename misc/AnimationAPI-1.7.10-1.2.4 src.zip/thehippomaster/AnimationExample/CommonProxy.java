package thehippomaster.AnimationExample;

public class CommonProxy {
	
	public void registerRenderers() {
	}
}
